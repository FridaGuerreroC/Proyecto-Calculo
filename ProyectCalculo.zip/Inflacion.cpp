// Librerias que utiliza el programa
#include <stdlib.h> //Librer�a de utilidades est�ndar
#include <stdio.h>  //Librer�a de entrada y salida est�ndar

//Prototipos de funci�n

void Inflacion1();
void Ciclo2017();
void Ciclo2019();

/*****************/
void Inflacion2();
void Ciclo2017();
void Ciclo2018();

/*****************/
void Inflacion3();
void Ciclo2020();
void Ciclo2022();

/****************/
void Inflacion4();
void Ciclo2021();

//Funci�n principal del programa
int main(){
	
	printf("\n      ---------------------------------------------------------- \n");
	printf("      - Programa que calcula la inflacion en lista de utiles   -\n");
	printf("      -                                                        -\n");
	printf("      ----------------------------------------------------------\n");
	
	/*Creamos un while que contiene un men� con  los ciclos escolares a evaluar,
	  dentro del while, tenemos una variable tipo char llamda opc, tenemos un switch-case
	  donde mandamos a llamar a las distintas funciones a evaluar, junto con las tablas de
	  utiles escolares.*/
	  
	while(1){
		printf("\nA continuacion se muestran los ciclos escolares que se evaluaran: \n\n");
		printf("a)Ciclos escolares: 2017-2018 y 2018-2019.\n");
		printf("b)Ciclos escolares: 2017-2018 y 2019-2020.\n");
		printf("c)Ciclos escolares: 2020-2021 y 2021-2022.\n");
		printf("d)Ciclos escolares: 2020-2021 y 2022-2023.\n");
		printf("f) Salir del programa\n");
		
		char opc;
		
		printf("Ingrese dos ciclos escolares: ");
		scanf("%c", &opc);
		
		switch(opc){
			case 'a':
				Inflacion1();
				Ciclo2017();
				Ciclo2019();
				system("pause");
                system("cls");
                break;
            case 'b':
            	Inflacion2();
            	Ciclo2017();
            	Ciclo2018();
            	system("pause");
                system("cls");
                break;
            case 'c':
            	Inflacion3();
            	Ciclo2020();
				Ciclo2022();
            	system("pause");
            	system("cls");
            	break;
            case 'd':
            	Inflacion4();
            	Ciclo2020();
            	Ciclo2021();
            	system("pause");
                system("cls");
                break;
            case 'f':
            	printf("Saliendo del programa...\n");
                system("pause");
                system("cls");
                exit(0);
            default:
            	printf("Opcion no valida.\n");
                system("pause");
                system("cls");
                break;
		}
	} 
	
	return 0;
}

/*Funci�n  Inflacion1 : Realiza el calculo del IPC, mediante un if, posteriormente  realiza una divisi�n de los totales de 
las listas de utiles, y lo multiplica por 100, seguido de ello, se realiza el calculo de la tasa de inflaci�n, donde solo se
realiza una resta entre el IPC obtenido menos una IPC base que es igual a 100, y asi obtenemos el porcentaje de inflaci�n 
entre ambos ciclos escolares.*/

void Inflacion1(){
	printf("Calculamos la inflacion de ambos ciclos: \n\n");
	printf("Para calcular la tasa inflacion entre ambos ciclos, primero debemos de calcular el Indice de Precios de Consumo (IPC)\n\n");
	printf("Calculamos el Indice de Precios de Consumo mediante la siguiente formula: \n\n");
	printf("IPC = (Total de precios del ciclo 2018-2019 / Total de precios del ciclo 2019-2020) * 100 \n\n");
	
	float Total_1= 776.69;
	float Total_2 = 905.88;
	
	float IpC1;
	
	if(Total_2 / Total_1 !=0){
		IpC1 = (Total_2/Total_1)*(100);
		printf("\n El Indice de Precios de Consumo es: $%f \n\n",IpC1);
	}else{
		printf("Error: El resultado es erroneo.");
	}
	
	printf("Calculamos la tasa inlfaci�n entre los ciclos escolares, 2017-2018 y 2019-2020\n\n");
	
	float IpC_1 = 116.63;
	int IpC_B = 100;
	float Inflacion_1;
	
	 if(IpC_1 - IpC_B != 0){
	 	Inflacion_1 = (IpC_1 - IpC_B);
	 	printf("La tasa de inflacion entre los ciclos 2017-2018 y 2019-2020 es: %f  \n\n",Inflacion_1);
	 } else{
	 	printf("Error= el resultado es erroneo");
	 }
}

/********************************************************************/

void Ciclo2017(){
	
	printf("* Ciclo 2017-2018 SECUNDARIA:      *\n");
	printf("************************************\n");
	printf("* UTILES ESCOLARES *    PRECIO     *\n");
	printf("************************************\n");
	printf("* Calculadora Basica $130.30       *\n");
	printf("************************************\n");
	printf("* Un bicolor $15.80                *\n");
	printf("************************************\n");
	printf("* Un boligrafo $33.55              *\n");
	printf("************************************\n");
	printf("* Un cuaderno de 100 hojas * $332.10\n");
	printf("************************************\n");
	printf("* Un juego de geometria $66.31     *\n");
	printf("************************************\n");
	printf("* Un lapiz $7.02                   *\n");
	printf("************************************\n");
	printf("* Un lapiz adhesivo $10.63         *\n");
	printf("************************************\n");
	printf("* Un marcatextos $10.50            *\n");
	printf("************************************\n");
	printf("* Un paquete de 100 hojas $25.00   *\n");
	printf("************************************\n");
	printf("* Un sacapuntas y una goma $22.50  *\n");
	printf("************************************\n");
	printf("* Lapices de colores $90.30        *\n");
	printf("************************************\n");
	printf("* Unas tijeras $32.50              *\n");
	printf("************************************\n");
	printf("* Total= $776.69                   *\n");
	printf("************************************\n");
}

/*********************************************************/

void Ciclo2019(){
	printf("\n\n");
	printf("* Ciclo 2019-2020 SECUNDARIA:       *\n");
	printf("*************************************\n");
	printf("* UTILES ESCOLARES *    PRECIO     *\n");
	printf("************************************\n");
	printf("* Calculadora Basica $149.23       *\n");
	printf("************************************\n");
	printf("* Un bicolor   $21.00              *\n");
	printf("************************************\n");
	printf("* Un boligrafo $40.40              *\n");
	printf("************************************\n");
	printf("* Un cuaderno de 100 hojas * $360.45\n");
	printf("************************************\n");
	printf("* Un juego de geometria $74.30     *\n");
	printf("************************************\n");
	printf("* Un lapiz $8.50                   *\n");
	printf("************************************\n");
	printf("* Un lapiz adhesivo $20.00         *\n");
	printf("************************************\n");
	printf("* Un marcatextos $15.50            *\n");
	printf("************************************\n");
	printf("* Un paquete de 100 hojas $30.00   *\n");
	printf("************************************\n");
	printf("* Un sacapuntas y una goma $32.50  *\n");
	printf("************************************\n");
	printf("* Lapices de colores $120.50       *\n");
	printf("************************************\n");
	printf("* Unas tijeras $33.50              *\n");
	printf("************************************\n");
	printf("* Total= $905.88                   *\n");
	printf("************************************\n");
}

/********************************************************/

/*Funci�n  Inflacion2 : Realiza el calculo del IPC, mediante un if, posteriormente  realiza una divisi�n de los totales de 
las listas de utiles, y lo multiplica por 100, seguido de ello, se realiza el calculo de la tasa de inflaci�n, donde solo se
realiza una resta entre el IPC obtenido menos una IPC base que es igual a 100, y asi obtenemos el porcentaje de inflaci�n 
entre ambos ciclos escolares.*/

void Inflacion2(){
	printf("Calculamos la inflacion de ambos ciclos: \n\n");
	printf("Para calcular la tasa inflacion entre ambos ciclos, primero debemos de calcular el Indice de Precios de Consumo (IPC)\n\n");
	printf("Calculamos el Indice de Precios de Consumo mediante la siguiente formula: \n\n");
	printf("IPC = (Total de precios del ciclo 2018-2019 / Total de precios del ciclo 2017-2018) * 100 \n\n");
	
	float Total_3 = 838.34;
	float Total_4 = 776.69;
	float IpC2;
	
	if(Total_4 / Total_3 !=0){
		IpC2 = (Total_4/Total_3)*(100);
		printf("\n El Indice de Precios de Consumo es: $%f \n\n",IpC2);
	}else{
		printf("Error: El resultado es erroneo.");
	}
	
	printf("Calculamos la tasa inlfacion entre los ciclos escolares, 2017-2018 y 2018-2019\n\n");
	
	float IpC_2 = 92.646179;
	int IpC_b = 100;
	float Inflacion_2;
	
	 if(IpC_2 - IpC_b != 0){
	 	Inflacion_2 = (IpC_2 - IpC_b);
	 	printf("La tasa de inflacion entre los ciclos 2017-2018 y 2018-2019 es: %f  \n\n",Inflacion_2);
	 } else{
	 	printf("Error: el resultado es erroneo");
	 }
	
}

/********************************************************************/

void Ciclo2018(){
	
	printf("\n\n");
	printf("*Ciclo 2018-2019 SECUNDARIA:       *\n");
	printf("************************************\n"); 
	printf("* UTILES ESCOLARES *    PRECIO     *\n");
	printf("************************************\n");
	printf("* Calculadora Basica $143.20       *\n");
	printf("************************************\n");
	printf("* Un bicolor   $19.95              *\n");
	printf("************************************\n");
	printf("* Un boligrafo $37.45              *\n");
	printf("************************************\n");
	printf("* Un cuaderno de 100 hojas * $347.40\n");
	printf("************************************\n");
	printf("* Un juego de geometria $69.23     *\n");
	printf("************************************\n");
	printf("* Un lapiz $8.02                   *\n");
	printf("************************************\n");
	printf("* Un lapiz adhesivo $16.03         *\n");
	printf("************************************\n");
	printf("* Un marcatextos $13.50            *\n");
	printf("************************************\n");
	printf("* Un paquete de 100 hojas $28.00   *\n");
	printf("************************************\n");
	printf("* Un sacapuntas y una goma $28.35  *\n");
	printf("************************************\n");
	printf("* Lapices de colores $96.60        *\n");
	printf("************************************\n");
	printf("* Unas tijeras $31.50              *\n");
	printf("************************************\n");
	printf("* Total= $838.84                   *\n");
	printf("************************************\n");
}


/**********************************************************************/

/*Funci�n  Inflacion3: Realiza el calculo del IPC, mediante un if, posteriormente  realiza una divisi�n de los totales de 
las listas de utiles, y lo multiplica por 100, seguido de ello, se realiza el calculo de la tasa de inflaci�n, donde solo se
realiza una resta entre el IPC obtenido menos una IPC base que es igual a 100, y asi obtenemos el porcentaje de inflaci�n 
entre ambos ciclos escolares.*/

void Inflacion3(){
	printf("Calculamos la inflacion de ambos ciclos: \n\n");
	printf("Para calcular la tasa inflacion entre ambos ciclos, primero debemos de calcular el Indice de Precios de Consumo (IPC)\n\n");
	printf("Calculamos el Indice de Precios de Consumo mediante la siguiente formula: \n\n");
	printf("IPC = (Total de precios del ciclo 2022-2023 / Total de precios del ciclo 2020-2021) * 100 \n\n");
	
	float Total_5 = 777;
	float Total_6 = 850;
	float IpC3;
	
	if(Total_6 / Total_5 !=0){
		IpC3 = (Total_6/Total_5)*(100);
		printf("\n El Indice de Precios de Consumo es: $%f \n\n",IpC3);
	}else{
		printf("Error: El resultado es erroneo.");
	}
	
	printf("Calculamos la tasa inlfacion entre los ciclos escolares, 2020-2021 y 2022-2023\n\n");
	
	float IpC_3 = 109.395111;
	int IpC_B = 100;
	float Inflacion_3;
	
	 if(IpC_3 - IpC_B != 0){
	 	Inflacion_3 = (IpC_3 - IpC_B);
	 	printf("La tasa de inflacion entre los ciclos 2020-2021 y 2022-2023 es: %f  \n\n",Inflacion_3);
	 } else{
	 	printf("Error: el resultado es erroneo");
	 }
	
	
}

void Ciclo2020(){
	
	
	
	printf("************************************\n");
	printf("*       CICLO 2020-2021            *\n");
	printf("\n************************************\n");
	printf("* UTILES ESCOLARES *    PRECIO     *\n");
	printf("************************************\n");
	printf("* Calucaladora Basica*      $200   *\n");
	printf("************************************\n");
	printf("* Lapiz Bicolor *            $10   *\n");
	printf("************************************\n");
	printf("* Un Boligrafo *             $7    *\n");
	printf("************************************\n");
	printf("* Cuaderno de 100 h *        $198  *\n");
	printf("************************************\n");
	printf("* Juego de geometria *        $55  *\n");
	printf("************************************\n");
	printf("* Un Lapiz *                  $5   *\n");
	printf("************************************\n");
	printf("* Lapiz Adhesivo *            $17  *\n");
	printf("************************************\n");
	printf("* Un Marcatextos *           $15   *\n");
	printf("************************************\n");
	printf("* 100 hojas blancas *       $150   *\n");
	printf("************************************\n");
	printf("* Sacapuntas y goma*        $10    *\n");
	printf("************************************\n");
	printf("* Lapices de colores *       $80   *\n");
	printf("************************************\n");
	printf("* Tijeras *                 $30    *\n");
	printf("************************************\n");
	printf("* TOTAL *                    $777  *\n");
	printf("************************************\n");
}

/*************************************************************/

void Ciclo2022(){
	
	printf("\n\n");
	
	printf("************************************\n");
	printf("*       CICLO 2022-2023            *\n");
	printf("\n************************************\n");
	printf("* UTILES ESCOLARES *    PRECIO     *\n");
	printf("************************************\n");
	printf("* Calucaladora Basica*      $200   *\n");
	printf("************************************\n");
	printf("* Lapiz Bicolor *            $10   *\n");
	printf("************************************\n");
	printf("* Un Boligrafo *             $7    *\n");
	printf("************************************\n");
	printf("* Cuaderno de 100 h *        $225  *\n");
	printf("************************************\n");
	printf("* Juego de geometria *        $65  *\n");
	printf("************************************\n");
	printf("* Un Lapiz *                  $5   *\n");
	printf("************************************\n");
	printf("* Lapiz Adhesivo *            $18  *\n");
	printf("************************************\n");
	printf("* Un Marcatextos *           $15   *\n");
	printf("************************************\n");
	printf("* 100 hojas blancas *       $175   *\n");
	printf("************************************\n");
	printf("* Sacapuntas y goma*        $10    *\n");
	printf("************************************\n");
	printf("* Lapices de colores *       $80   *\n");
	printf("************************************\n");
	printf("* Tijeras *                 $40    *\n");
	printf("************************************\n");
	printf("* TOTAL *                    $850  *\n");
	printf("************************************\n");
	
}
/********************************************************************************/

/*Funci�n  Inflacion4 : Realiza el calculo del IPC, mediante un if, posteriormente  realiza una divisi�n de los totales de 
las listas de utiles, y lo multiplica por 100, seguido de ello, se realiza el calculo de la tasa de inflaci�n, donde solo se
realiza una resta entre el IPC obtenido menos una IPC base que es igual a 100, y asi obtenemos el porcentaje de inflaci�n 
entre ambos ciclos escolares.*/


void Inflacion4(){
	printf("Calculamos la inflacion de ambos ciclos: \n\n");
	printf("Para calcular la tasa inflacion entre ambos ciclos, primero debemos de calcular el Indice de Precios de Consumo (IPC)\n\n");
	printf("Calculamos el Indice de Precios de Consumo mediante la siguiente formula: \n\n");
	printf("IPC = (Total de precios del ciclo 2020-2021 / Total de precios del ciclo 202-2022) * 100 \n\n");
	
	float Total_7 = 777;
	float Total_8 = 638.42;
	float IpC4;
	
	if(Total_8 / Total_7 !=0){
		IpC4 = (Total_8/Total_7)*(100);
		printf("\n El Indice de Precios de Consumo es: $%f \n\n",IpC4);
	}else{
		printf("Error: El resultado es erroneo.");
	}
	
	printf("Calculamos la tasa inlfacion entre los ciclos escolares, 2020-2021 y 2022-2023\n\n");
	
	float IpC_4 = 82.164734;
	int IpC_B = 100;
	float Inflacion_4;
	
	 if(IpC_4 - IpC_B != 0){
	 	Inflacion_4 = (IpC_4 - IpC_B);
	 	printf("La tasa de inflacion entre los ciclos 2020-2021 y 2022-2023 es: %f  \n\n",Inflacion_4);
	 } else{
	 	printf("Error: el resultado es erroneo");
	 }
	
	
}

void Ciclo2021(){
	
	printf("\n\n");
	
	printf("************************************\n");
	printf("*       CICLO 2021-2022            *\n");
	printf("\n**********************************\n");
	printf("* UTILES ESCOLARES *    PRECIO     *\n");
	printf("************************************\n");
	printf("* Calculadora Basica*      $89     *\n");
	printf("************************************\n");
	printf("* Lapiz Bicolor *            $14   *\n");
	printf("************************************\n");
	printf("* Un Boligrafo *             $7.22 *\n");
	printf("************************************\n");
	printf("* Cuaderno de 100 h *       $120.15*\n");
	printf("************************************\n");
	printf("* Juego de geometria *      $104.14*\n");
	printf("************************************\n");
	printf("* Un Lapiz *                  $5   *\n");
	printf("************************************\n");
	printf("* Lapiz Adhesivo *           $15.30*\n");
	printf("************************************\n");
	printf("* Un Marcatextos *          $46.33 *\n");
	printf("************************************\n");
	printf("* 100 hojas blancas *       $86.25 *\n");
	printf("************************************\n");
	printf("* Sacapuntas y goma*        $22.03 *\n");
	printf("************************************\n");
	printf("* Lapices de colores *       $89   *\n");
	printf("************************************\n");
	printf("* Tijeras *                 $40    *\n");
	printf("************************************\n");
	printf("* TOTAL *                 $638.42  *\n");
	printf("************************************\n");
}
